// Profile popup functionality
const profileButton = document.getElementById("profile-button");
const profilePopup = document.getElementById("profile-popup");
const backdrop = document.getElementById("backdrop");
const profileContainer = document.querySelector(".container_1");

profileButton.addEventListener("click", () => {
  profilePopup.classList.toggle("open");
  backdrop.classList.toggle("active");
});

backdrop.addEventListener("click", () => {
  profilePopup.classList.remove("open");
  backdrop.classList.remove("active");
});

profilePopup.addEventListener("click", (evt) => {
  if (evt.target.matches(".btn.signup")) {
    profileContainer.classList.add("active");
  } else if (evt.target.matches(".btn.login")) {
    profileContainer.classList.remove("active");
  }
});


// Handle hover effect for images
document.addEventListener('DOMContentLoaded', function() {
  // Handle hover effect for images
  var images = document.querySelectorAll('.hover-image');
  
  images.forEach(function(image) {
    image.addEventListener('mouseover', function() {
      this.style.transform = 'scale(1.1)';
    });
    
    image.addEventListener('mouseout', function() {
      this.style.transform = 'scale(1)';
    });
  });
});

//dasdasd
document.addEventListener('DOMContentLoaded', () => {
  // Get all links with hashes
  const links = document.querySelectorAll('a[href^="#"]');

  links.forEach(link => {
    link.addEventListener('click', function (e) {
      e.preventDefault();
      
      // Get the target element
      const targetId = this.getAttribute('#best_seller').substring(1);
      const targetElement = document.getElementById(best_seller);
      
      if (targetElement) {
        // Scroll smoothly to the target element
        targetElement.scrollIntoView({
          behavior: 'smooth',
          block: 'center'
        });
      }
    });
  });
});

// for bar nyar
document.addEventListener("DOMContentLoaded", function () {
  var swiper = new Swiper(".swiper", {
    effect: "cards",
    grabCursor: true,
    initialSlide: 2,
    speed: 500,
    loop: true,
    rotate: true,
    mousewheel: {
      invert: false,
    },
  });
});



// For footer
  document.querySelectorAll('.footer a').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      document.querySelector(this.getAttribute('href')).scrollIntoView({
        behavior: 'smooth'
      });
    });
  });
  
